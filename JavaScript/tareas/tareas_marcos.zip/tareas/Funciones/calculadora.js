"use strict";

const prompt = require('prompt-sync')();

function menu() {
    console.log( 
        "+ para sumar" + "\n" + 
        "- para restar" + "\n" + 
        "* para multiplicar" + "\n" + 
        "/ para dividir" + "\n" + 
        "% para ver el residuo" + "\n" + 
        "R para cargar la memoria" + "\n" + 
        "C para limpiar la memoria" + "\n" + 
        "S para salir" + "\n"
    );
}

menu();

let memoria = 0;
let operador = "";

function realizarOperacion() {    
    let pantalla = 0;

    while (operador !== "S") {
        console.log("\nValor actual: " + pantalla);

        operador = prompt("Operador: ").toUpperCase();

        if (operador === "S") {
            console.log("Saliendo...");
            break;
        }

        switch(operador) {
            case "+":
            case "-":
            case "*":
            case "/":
            case "%":
                let operando2 = Number(prompt("Introduce otro operando: "));
                if (isNaN(operando2)) {
                    console.log("Operando no válido.");
                    continue;
                }
                switch(operador){
                    case "+": pantalla += operando2; break;
                    case "-": pantalla -= operando2; break;
                    case "*": pantalla *= operando2; break;
                    case "/": 
                        if (operando2 === 0) {
                            console.log("No se puede dividir entre 0.");
                            continue;
                        }
                        pantalla /= operando2; 
                        break;
                    case "%": pantalla %= operando2; break;
                }
                console.log("Resultado: " + pantalla);
                memoria = pantalla;
                break;

            case "R":
                pantalla = memoria;
                console.log("Memoria cargada: " + pantalla);
                break;

            case "C":
                memoria = 0;
                pantalla = 0;
                console.log("Memoria y pantalla limpiadas.");
                break;

            default:
                console.log("Operador no válido.");
        }
    }
}

realizarOperacion();
