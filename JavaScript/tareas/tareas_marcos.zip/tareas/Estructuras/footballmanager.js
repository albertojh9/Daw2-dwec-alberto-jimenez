"use strict";

const prompt = require('prompt-sync')();

const jugadores = new Map();
let numero = 0;

do{
    numero = Number(prompt("Escriba un numero: "));

    if(numero === 0){ break; }

    if(jugadores.has(numero)){
        console.log("Ese numero ya está cogido")
    } else{
        let nombre = prompt("Escriba un nombre: ");
        jugadores.set(numero, nombre);
    }

}while(numero != 0);

let numeroConsulta = 0;

do{
    numeroConsulta = Number(prompt("Introduzca un numero para ver el jugador que lo tiene: "));

    if(numeroConsulta === 0){ break; };

    let numeroJugadores = jugadores.get(numeroConsulta);

    if(numeroJugadores){
        console.log("El número que lleva ese jugador es: " + numeroJugadores);
    } else{
        console.log("No hay ningun jugador con ese número")
    }

}while(numeroConsulta != 0);