"use-strict";

const prompt = require('prompt-sync')();
const valorMaximo = 20;
let numerosAleatorios = [];

for(let i = 0; i < valorMaximo; i++){
     let numeroAleatorio = Math.floor(Math.random() * (valorMaximo + 1));
     numerosAleatorios.push(numeroAleatorio);

}

let numerosUsuarios = [];
const intentos = 5;

for(let i = 0; i < intentos; i++){
    let numero = Number(prompt(`Introduce el número ${i + 1}: `));
    numerosUsuarios.push(numero);
}

let cantidadAciertos = 0;
let numerosAcertados = [];
for(let i = 0; i < numerosUsuarios.length; i++){
    let numero = numerosUsuarios[i];

    if(numerosAleatorios.includes(numero) && !numerosAcertados.includes(numero)){
        numerosAcertados.push(numero);
        cantidadAciertos++;
    }
}

console.log("Has acertado " + cantidadAciertos + " numero/s");
console.log("Los numeros acertados son: " + numerosAcertados);