"use strict";

const prompt = require('prompt-sync')();

let listaCompra = [];
let elemento;

while(true){

    elemento = prompt("Elemento: ");

    if(elemento === ""){
        break;
    }

    let elementoLower = elemento.toLowerCase();

    if(listaCompra.includes(elementoLower)){
        console.log("Ese elemento ya existe, introudzca otro")
    } else{
        listaCompra.push(elementoLower);
        console.log("El elemento se ha añadido correctamente");
    }
}

console.log("Lista de la compra: " + listaCompra);