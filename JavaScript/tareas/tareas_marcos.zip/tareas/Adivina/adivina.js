const prompt = require('prompt-sync')();

const valorMaximo = 100;
const numeroAleatorio = Math.floor(Math.random() * valorMaximo);
let acierto = false;


const numeroIntentos = Number(prompt("Escriba el numero de intentos: "));

for(let i = 1; i <= numeroIntentos && !acierto; i++){
    const intento = Number(prompt("Intento " + i + ": "));
    if(intento === numeroAleatorio){
        console.log("Felicidades, has adivinado el numero");
        acierto = true;
    } else{
        console.log(intento > numeroAleatorio ? "El numero que has introducido es mayor" : "El numero que has introducido es menor");
    }
}

if(!acierto){
    console.log('Has perdido, el numero era: ' + numeroAleatorio);
}
